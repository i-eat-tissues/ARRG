<?php // no closing off this bc this is a pure php file!! meaning the whole file wil be written in php:D
//this is code for a DataBase Handler, hence the name.

$host = "host";
$dbname = "database_name";
$dbUsername = "database_username";
$dbPassword = "database_password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $dbUsername, $dbPassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}catch (PDOException $e) {
    echo "crumbs:( something bwoke : " . $e->getMessage();
}
